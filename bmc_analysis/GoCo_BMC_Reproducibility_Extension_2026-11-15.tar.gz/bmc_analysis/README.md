# GoCo BMC Bioinformatics — archived matched-fold and four-panel raw-input ordering ablation complete

## Completed: archived split-level matched comparisons

Main manuscript Table 5 and Supplementary Note S6/Table S14/Figure S3 have been compiled from an analysis of the original 100-split archive. The `results/goco_results_100splits.csv` file **already** contains `GoDag-cert60`, which uses the same 60% certification fold as GoCo-M, and the two neighbourhood-family archives contain both GoCo-N and matched `global-dense`. The new analyses are **paired post hoc computations of the original archived results** (not new model fits). Run from the updated source ZIP:

```bash
python bmc_analysis/paired_archive/analyze_transport.py
python bmc_analysis/paired_archive/make_paired_figure.py
```

If a checkout of the frozen public repository is available, independently reproduce all paired differences from original CSVs:

```bash
python bmc_analysis/paired_archive/reproduce_from_repo.py --repo /path/to/ConformalGoCo
```

The exact source commit and three source blob hashes are pinned in `paired_archive/provenance.json`. A synthetic fixture tests that the extractor reconstructs all 800 archived paired differences. The Monte Carlo intervals are summaries across split randomizations of the **same fixed biological panels**, not independent biological confidence intervals. See `CHANGELOG_EMPIRICAL.md` and `EMPIRICAL_EVIDENCE_SUMMARY.md`.

## Completed: raw-input learned-vs-nonbiological ordering ablation for four module panels

The four module panels (Wainberg, Sanger, DRIVE and HAP1) have now been rerun on the original frozen input matrices, and the learned, score-only, and three per-split hash controls are reported in the main text and Supplementary Note S7. See `ORDERING_ABLATION_README.md` and `ordering_ablation/` for complete 100-split outputs and verification. The large FunMap and STRING *neighbourhood family* raw scores remain unavailable, so that separate ordering ablation has **not** been run.

## Commands once the original inputs are available

```bash
pip install -r /path/to/ConformalGoCo/code/requirements.txt
python bmc_analysis/run_matched_ablation.py --repo /path/to/ConformalGoCo --families module --datasets Wainberg,Sanger,DRIVE,HAP1 --repeats 100 --random-reps 3 --out results/bmc_module
python bmc_analysis/run_matched_ablation.py --repo /path/to/ConformalGoCo --families neighborhood --data funmap --repeats 100 --random-reps 3 --out results/bmc_funmap
python bmc_analysis/run_matched_ablation.py --repo /path/to/ConformalGoCo --families neighborhood --data string/funmap_view --repeats 100 --random-reps 3 --out results/bmc_string
```

The script exits if required files are missing and never modifies the original results. It writes separate `*_split_level.csv`, `*_summary.csv`, and `*_paired.csv` files. `random` is averaged **within a split** for the pairwise comparison, not counted as additional independent evidence. Report means and split-distribution quantiles as split-randomization summaries, not independent biological confidence intervals. Compare the outcome of learned versus controls under the same certification test. Sensitivity to the random-ordering hash replication should be examined; no difference is guaranteed.

To reproduce the *existing* FunMap and STRING panel at `alpha=0.10, delta=0.10`, which was newly promoted into the main manuscript, run:

```bash
python bmc_analysis/summarize_existing_neighborhood.py --repo /path/to/ConformalGoCo --out results/strictN_verification.csv
```

The expected BMC main Table `strictN` means are (FunMap: refined GoDag 0.0941 FDP, 2061.2 total, 1279.8 supported; GoCo-N 0.0878, 2165.5, 1615.8; STRING: refined GoDag 0.0928, 1840.1, 909.2; GoCo-N 0.0894, 1622.3, 1151.1). These values were independently aggregated from the **already stored 100-split CSVs** via the GitHub connector, not recomputed from raw data.

## Interpretation and stop rule

A positive learned-versus-hash paired supported-yield difference supports a benefit beyond simply adding candidate policies, but even then it does not establish general superiority for new genes or GO reference versions. If controls perform similarly or better, report the outcome and narrow the claims to policy granularity/fixed-panel usefulness. The manuscript does not claim these new results until the actual source inputs and analyses have been verified.
