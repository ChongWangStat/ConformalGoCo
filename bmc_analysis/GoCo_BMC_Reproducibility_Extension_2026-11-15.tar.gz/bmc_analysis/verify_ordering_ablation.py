#!/usr/bin/env python3
"""Recalculate the GoCo-M ablation table from the 100 original split-level runs per panel.
Usage: python bmc_analysis/verify_ordering_ablation.py
"""
from pathlib import Path
import pandas as pd
root=Path(__file__).resolve().parent/'ordering_ablation'
expected={('Wainberg','random'):21.906667,('Wainberg','score-only'):24.09,
          ('Sanger','random'):7.796667,('Sanger','score-only'):7.82,
          ('DRIVE','random'):14.41,('DRIVE','score-only'):13.22,
          ('HAP1','random'):3.756667,('HAP1','score-only'):-.19}
for ds in ['Wainberg','Sanger','DRIVE','HAP1']:
    d=pd.read_csv(root/f'{ds}_100splits.csv')
    assert len(d)==700,(ds,len(d))
    assert sorted(d.seed.unique().tolist())==list(range(100))
    assert not d.duplicated(['seed','arm','hash_rep']).any()
    a=d.groupby(['seed','arm'],as_index=False).agg(supported=('go_yield','mean'),total=('total_calls','mean'))
    learned=a[a.arm=='GoCo-learned'].set_index('seed')
    for comp in ['random','score-only']:
        ctrl=a[a.arm==comp].set_index('seed')
        assert len(learned)==len(ctrl)==100
        dy=(learned.supported-ctrl.supported).mean()
        assert abs(dy-expected[ds,comp])<0.001,(ds,comp,dy)
        print(f'{ds} learned - {comp}: +{dy:.3f} supported; total delta {(learned.total-ctrl.total).mean():.3f}')
print('Verified 400 splits, 2800 arm/hash rows, 8 primary contrasts.')
