#!/usr/bin/env python3
"""GoCo BMC Bioinformatics matched-fold and ordering ablations.

Run from the root of the *original*, frozen ConformalGoCo repository, e.g.:
  python path/to/run_matched_ablation.py --repo . --families module --repeats 100 --random-reps 3
  python path/to/run_matched_ablation.py --repo . --families neighborhood --data funmap --repeats 100
  python path/to/run_matched_ablation.py --repo . --families neighborhood --data string/funmap_view --repeats 100

This is a separate research extension: never overwrite existing results or manuscript tables.
Fold identities, scores, GO labels, risk criterion, certification test, and candidate-grid
resolution are inherited exactly from the original repository. The ordered-policy arms
all use the same ranking/certification/evaluation fold within a split. Labels in the
certification or evaluation folds never construct the candidate ordering.

NOTES: A SHA-256 order fixed before certification is a nonbiological negative control;
it does not provide a guarantee of higher yield or of independence from every biological
feature in the frozen finite panel. Rank-fold cross-fitting is unchanged in the learned arm.
Repeated hash orderings on a given split must be averaged *within split* for comparisons;
they are not additional independent biological observations.
"""
from __future__ import annotations
import argparse
import contextlib
import importlib
import os
from pathlib import Path
import sys
import numpy as np
import pandas as pd

METRICS = ["unit_fdp", "go_yield", "total_calls", "genes_with_calls", "pool_risk"]


def _check(root: Path, relpaths: list[str]):
    missing = [x for x in relpaths if not (root / x).is_file()]
    if missing:
        raise FileNotFoundError("Frozen inputs missing (do not substitute summaries): " + ", ".join(missing))


def _results(out: Path, rows: list[dict], target: str):
    out.mkdir(parents=True, exist_ok=True)
    raw = pd.DataFrame(rows)
    if raw.empty: raise RuntimeError("No analysis results")
    raw.to_csv(out / f"{target}_split_level.csv", index=False)
    group = ["dataset", "alpha", "delta", "arm"]
    summary = raw.groupby(group, as_index=False).agg(
        mean_fdp=("unit_fdp", "mean"), mean_supported=("go_yield", "mean"),
        mean_total=("total_calls", "mean"), mean_annotated=("genes_with_calls", "mean"),
        pool_failure=("pool_failure", "mean"), n_splits=("seed", "nunique"))
    summary.to_csv(out / f"{target}_summary.csv", index=False)
    # For random controls, average over hash repetitions before pairing within seed.
    keyed = raw.groupby(["dataset", "seed", "alpha", "delta", "arm"], as_index=False)[METRICS].mean()
    learned = keyed[keyed.arm == "GoCo-learned"].drop(columns="arm")
    pairs = []
    for arm in ["GoDag60", "GoDag70", "GoDag-refined60", "random", "score-only"]:
        rival = keyed[keyed.arm == arm].drop(columns="arm")
        if rival.empty or learned.empty: continue
        d = learned.merge(rival, on=["dataset", "seed", "alpha", "delta"], suffixes=("_learned", "_control"))
        for metric in METRICS:
            dv = d[f"{metric}_learned"] - d[f"{metric}_control"]
            for data, a, de in sorted(set(zip(d.dataset, d.alpha, d.delta))):
                q = dv[(d.dataset == data) & (d.alpha == a) & (d.delta == de)]
                pairs.append(dict(dataset=data, alpha=a, delta=de, control=arm, metric=metric,
                                  n_splits=len(q), mean_paired_difference=q.mean(),
                                  median_paired_difference=q.median(), split_q025=q.quantile(0.025),
                                  split_q975=q.quantile(0.975), fraction_positive=(q > 0).mean()))
    pd.DataFrame(pairs).to_csv(out / f"{target}_paired.csv", index=False)
    return summary


def run_module(root, args):
    _check(root, ["code/goco_rerun.py", "code/goco_learned.py", "w/go_truth_direct.csv.gz", "w/go_truth_true_path.csv.gz", "w/network_communities.csv"])
    sys.path.insert(0, str(root / "code"))
    gr = importlib.import_module("goco_rerun")
    orig_utility = gr.utility
    # run_path sets utility.extra on its current utility function. Propagate it for original GoCo.
    mode = {"seed": -1, "rep": 0}
    def utility(order, ds, Aadd, meanscore, delta_true, cadd, affected, train, hh_default):
        if order == "goco":
            orig_utility.extra = utility.extra
            return orig_utility(order, ds, Aadd, meanscore, delta_true, cadd, affected, train, hh_default)
        if order == "hash":
            h = gr.hashu(ds.units, salt=f"bmc-hash-{mode['seed']}-{mode['rep']}")
            return np.where(affected, h, np.inf), hh_default
        if order == "score":
            # Score-only negative control. On exactly tied Wainberg blocks the
            # scores are the same; the prespecified identifier hash breaks ties.
            u = np.where(affected & np.isfinite(meanscore), -meanscore, np.inf)
            return u, hh_default
        raise ValueError(order)
    gr.utility = utility
    direct, truepath = gr.load_truth()
    output = []
    try:
        for name in args.datasets.split(","):
            ds = gr.Dataset(name, direct, truepath)
            mg = ds.mats(ds.grid)
            if name == "Wainberg":
                j800 = int(np.where(ds.grid == 800)[0][0])
                mw = ds.mats(np.concatenate([ds.grid[:j800 + 1], [789.65]]))
            else:
                mw = mg
            for seed in range(args.start, args.start + args.repeats):
                mode["seed"] = seed
                perm = np.random.default_rng(gr.SEED0 + seed).permutation(ds.n)
                nt, nc = round(.10 * ds.n), round(.70 * ds.n)
                train, cert, ev, cal70 = perm[:nt], perm[nt:nc], perm[nc:], perm[:nc]
                def path(arm, rep=0):
                    mode["rep"] = rep
                    if name == "Wainberg":
                        return gr.run_path(ds, mw, cert, ev, train, args.alpha, args.delta,
                            "TruePath", arm, gr.QGRID_W, False,
                            lambda j: ds.Aadd(789.65, 800.), {}, adapt_blocks={len(mw["thr"]) - 2})
                    return gr.run_path(ds, mg, cert, ev, train, args.alpha, args.delta,
                        "TruePath", arm, gr.QGRID_E, True,
                        lambda j: ds.Aadd(mg["thr"][j + 1], mg["thr"][j]), {})
                arms = [("GoDag70", 0, gr.run_path(ds, mg, cal70, ev, train, args.alpha, args.delta,
                          "TruePath", None, None, False, None, {}), mg, cal70),
                        ("GoDag60", 0, gr.run_path(ds, mg, cert, ev, train, args.alpha, args.delta,
                          "TruePath", None, None, False, None, {}), mg, cert)]
                arms.append(("GoCo-learned", 0, path("goco"), mw, cert))
                arms.append(("score-only", 0, path("score"), mw, cert))
                for rep in range(args.random_reps):
                    arms.append(("random", rep, path("hash", rep), mw, cert))
                for arm, rep, selected, M, fold in arms:
                    met = gr.metrics(ds, M, selected, ev, fold)
                    output.append(dict(dataset=name, seed=seed, alpha=args.alpha, delta=args.delta,
                                       arm=arm, hash_rep=rep, **{k: met[k] for k in METRICS},
                                       pool_failure=int(met["pool_risk"] > args.alpha),
                                       policy=met["policy"]))
                print(f"{name}: {seed + 1}/{args.start + args.repeats} complete", flush=True)
                if (seed + 1 - args.start) % 5 == 0:
                    Path(args.out).mkdir(parents=True,exist_ok=True)
                    pd.DataFrame(output).to_csv(Path(args.out)/"module_checkpoint.csv",index=False)
    finally:
        gr.utility = orig_utility
    return _results(Path(args.out), output, "module")


def run_neighborhood(root, args):
    _check(root, ["code/goco_second_family.py"])
    data = Path(args.data)
    if not data.is_absolute(): data = root / data
    _check(data, ["funmap_gene_go_scores.csv.gz", "go_truth_true_path.csv.gz",
                   "go_truth_direct.csv.gz", "funmap_edges.csv.gz", "author_top50_neighborhoods_lopo.csv.gz"])
    os.environ["GOCO_DATA"] = str(data)
    sys.path.insert(0, str(root / "code"))
    sf = importlib.import_module("goco_second_family")
    ds = sf.FunMap()
    M = ds.mats(sf.DENSE)
    i = ds.rows.i.to_numpy()
    y = ds.rows["T"].to_numpy(np.int32)
    score = ds.rows.score.to_numpy(float)
    call_key = ds.rows.gene.astype(str) + "|" + ds.rows.go_id.astype(str)
    hcall = ds.hcall  # preserve the exact released GoCo-N tie-breaker for every arm
    output = []
    for seed in range(args.start, args.start + args.repeats):
        perm = np.random.default_rng(sf.SEED0 + seed).permutation(ds.n)
        nt, nc = round(.10 * ds.n), round(.70 * ds.n)
        train, cert, ev = perm[:nt], perm[nt:nc], perm[nc:]
        phat, _ = ds.fit_phat(train)
        def candidates(p):
            C, Y, L, edges = sf.topm_path(p, hcall, i, y, ds.n, sf.MFRAC_N)
            return [(f"top{int(edges[j])}", L[:,j], C[:,j], Y[:,j]) for j in range(len(edges))]
        def evaluate(arm, rep, cands):
            selected = None
            for name, L, C, Y in cands:
                if sf.clt_p(L[cert], args.alpha) > args.delta: break
                selected = (name, L, C, Y)
            if selected is None:
                fdp, sup, total, covered, risk, label = 0., 0., 0., 0., 0., "abstain"
            else:
                label, L, C, Y = selected
                fdp = float(L[ev].mean()); sup=float(Y[ev].sum()); total=float(C[ev].sum())
                covered = int((C[ev] > 0).sum()); risk = float(L[np.r_[cert, ev]].mean())
            output.append(dict(dataset=data.name, seed=seed, alpha=args.alpha, delta=args.delta,
                               arm=arm, hash_rep=rep, unit_fdp=fdp, go_yield=sup,
                               total_calls=total, genes_with_calls=covered, pool_risk=risk,
                               pool_failure=int(risk > args.alpha), policy=label))
        # Refined score grid: same evaluation/certification fold.
        cg = [(f"global_{sf.DENSE[j]:g}", M["L"][:,j], M["C"][:,j], M["Y"][:,j])
              for j in range(len(sf.DENSE)-1, -1, -1)]
        evaluate("GoDag-refined60", 0, cg)
        evaluate("GoCo-learned", 0, candidates(phat))
        evaluate("score-only", 0, candidates(-score))
        for rep in range(args.random_reps):
            random_key = sf.hashu(call_key.to_numpy(), salt=f"bmc-random-{seed}-{rep}")
            evaluate("random", rep, candidates(random_key))
        print(f"{data}: {seed + 1}/{args.start + args.repeats} complete", flush=True)
    return _results(Path(args.out), output, data.name)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--repo", required=True, help="Path to the checked-out frozen ConformalGoCo repository")
    p.add_argument("--families", choices=["module", "neighborhood"], required=True)
    p.add_argument("--datasets", default="Wainberg,Sanger,DRIVE,HAP1")
    p.add_argument("--data", default="funmap", help="Input directory for the neighborhood family")
    p.add_argument("--alpha", type=float, default=0.10)
    p.add_argument("--delta", type=float, default=0.10)
    p.add_argument("--start", type=int, default=0)
    p.add_argument("--repeats", type=int, default=100)
    p.add_argument("--random-reps", type=int, default=3)
    p.add_argument("--out", default="bmc_analysis/results", help="New output directory; original results never overwritten")
    a=p.parse_args()
    root=Path(a.repo).resolve()
    assert (root/'code'/'goco_rerun.py').exists(), f"Not the original repo: {root}"
    if a.delta <= 0 or a.delta > 0.5: raise ValueError("Delta must lie in (0,0.5] for the stated guarantee")
    if a.repeats < 1 or a.random_reps < 1: raise ValueError("Replicates must be positive")
    summary = run_module(root,a) if a.families == "module" else run_neighborhood(root,a)
    print(summary.to_string(index=False))

if __name__=='__main__': main()
