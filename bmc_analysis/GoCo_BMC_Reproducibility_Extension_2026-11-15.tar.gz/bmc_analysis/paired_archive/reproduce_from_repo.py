#!/usr/bin/env python3
"""Reproduce the post-hoc paired split comparison from the archived GoCo CSVs.

This does NOT rerun gene-level predictions or the biological-ordering ablation.
It reads already frozen, published split-level results. Compare paired split
indices, not unpaired aggregate averages. Requires no original large raw inputs.

Usage:
  python bmc_analysis/paired_archive/reproduce_from_repo.py --repo /path/to/ConformalGoCo
"""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd

TARGET_ALPHA=0.10
TARGET_DELTA=0.10
EXPECTED = {
 ('M','Wainberg','GoDag60'):25.61,
 ('M','Sanger','GoDag60'):19.24,
 ('M','DRIVE','GoDag60'):27.06,
 ('M','HAP1','GoDag60'):8.14,
 ('N','funmap','GoDagDense'):335.95,
 ('N','string','GoDagDense'):241.98,
 ('N','funmap','GoCoM'):141.32,
 ('N','string','GoCoM'):130.04,
}

def extract(repo):
    rows=[]
    mod=pd.read_csv(repo/'results/goco_results_100splits.csv')
    mod=mod[np.isclose(mod.alpha,TARGET_ALPHA)&np.isclose(mod.delta,TARGET_DELTA)]
    for dataset in ('Wainberg','Sanger','DRIVE','HAP1'):
        df=mod[mod.dataset==dataset]
        left=df[df.method=='GoCo'][['seed','go_yield','total_calls']]
        right=df[df.method=='GoDag-cert60'][['seed','go_yield','total_calls']]
        assert not left.seed.duplicated().any() and not right.seed.duplicated().any()
        x=left.merge(right,on='seed',suffixes=('_g','_c'),validate='one_to_one')
        assert len(x)==100 and set(x.seed)==set(range(100))
        for t in x.itertuples(index=False):
            rows.append({'family':'M','dataset':dataset,'control':'GoDag60','split':int(t.seed),
                         'delta_supported':int(round(t.go_yield_g-t.go_yield_c)),
                         'delta_total':int(round(t.total_calls_g-t.total_calls_c))})
    for dataset in ('funmap','string'):
        df=pd.read_csv(repo/f'results/sf/{dataset}_v4_100.csv')
        df=df[np.isclose(df.alpha,TARGET_ALPHA)&np.isclose(df.delta,TARGET_DELTA)]
        left=df[df.arm=='goco-N'][['repeat','correct','total']]
        for ctrl,arm in (('GoDagDense','global-dense'),('GoCoM','goco-M')):
            right=df[df.arm==arm][['repeat','correct','total']]
            assert not left.repeat.duplicated().any() and not right.repeat.duplicated().any()
            x=left.merge(right,on='repeat',suffixes=('_g','_c'),validate='one_to_one')
            assert len(x)==100 and set(x.repeat)==set(range(100))
            for t in x.itertuples(index=False):
                rows.append({'family':'N','dataset':dataset,'control':ctrl,'split':int(t.repeat),
                             'delta_supported':int(t.correct_g-t.correct_c),
                             'delta_total':int(t.total_g-t.total_c)})
    result=pd.DataFrame(rows).sort_values(['family','dataset','control','split']).reset_index(drop=True)
    assert len(result)==800 and not result.duplicated(['family','dataset','control','split']).any()
    return result

def summarize(x):
    results=[]
    for (fam,data,ctrl),g in x.groupby(['family','dataset','control']):
        for metric in ('delta_supported','delta_total'):
            v=g.sort_values('split')[metric].to_numpy(float)
            n=len(v); se=float(v.std(ddof=1)/np.sqrt(n));mean=float(v.mean())
            results.append(dict(family=fam,dataset=data,control=ctrl,metric=metric,n_splits=n,
                                mean_difference=mean,mc_se=se,mc_ci_lower=mean-1.96*se,
                                mc_ci_upper=mean+1.96*se,positive_splits=int((v>0).sum()),
                                negative_splits=int((v<0).sum()),tied_splits=int((v==0).sum()),
                                median_difference=float(np.median(v))))
    return pd.DataFrame(results)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--repo',type=Path,required=True)
    p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent/'regenerated')
    a=p.parse_args()
    x=extract(a.repo)
    s=summarize(x)
    for (fam,d,ctrl),expected in EXPECTED.items():
        z=s[(s.family==fam)&(s.dataset==d)&(s.control==ctrl)&(s.metric=='delta_supported')]
        assert len(z)==1 and abs(z.mean_difference.iloc[0]-expected)<1e-8,(fam,d,ctrl,z)
    a.out.mkdir(parents=True,exist_ok=True)
    x.to_csv(a.out/'paired_split_differences.csv',index=False)
    s.to_csv(a.out/'paired_results.csv',index=False)
    print(s.to_string(index=False))
if __name__=='__main__':main()
