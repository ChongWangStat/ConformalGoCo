"""Analyze 100 paired split differences extracted from archived CSVs.
Source: ChongWangStat/ConformalGoCo commit-frozen release, alpha=.10, delta=.10.
Transport is base64 little-endian signed 16-bit [supported_difference,total_difference]
for each split, 100 splits in ascending seed order. Comparison and source hashes
recorded in provenance.json. No new calibrator fitting or ablation is inferred.
"""
import base64, json, numpy as np, pandas as pd
from pathlib import Path
ROOT=Path(__file__).resolve().parent
raw=(ROOT/'pairs_base64.txt').read_text().strip().splitlines()
records=[]; summary=[]
for line in raw:
    if not line.strip() or line.startswith('#'): continue
    fam,dset,ctrl,packed=line.strip().split('|',3)
    a=np.frombuffer(base64.b64decode(packed),dtype='<i2')
    assert a.size==200,(dset,a.size)
    a=a.reshape(100,2)
    for i,(sup,total) in enumerate(a):
        records.append({'family':fam,'dataset':dset,'control':ctrl,'split':i,
                        'delta_supported':int(sup),'delta_total':int(total)})
    for j,metric in enumerate(('delta_supported','delta_total')):
        v=a[:,j].astype(float); se=float(v.std(ddof=1)/np.sqrt(len(v)))
        # MC interval about the average over random splits: not population inference
        summary.append({'family':fam,'dataset':dset,'control':ctrl,'metric':metric,
                        'splits':len(v),'mean_difference':v.mean(),
                        'mc_se':se,'mc_ci_lower':v.mean()-1.96*se,
                        'mc_ci_upper':v.mean()+1.96*se,
                        'split_q025':np.quantile(v,.025), 'split_q975':np.quantile(v,.975),
                        'positive_splits':int((v>0).sum()),'negative_splits':int((v<0).sum()),
                        'tied_splits':int((v==0).sum()),'median_difference':np.median(v)})
D=pd.DataFrame(records);S=pd.DataFrame(summary)
D.to_csv(ROOT/'paired_split_differences.csv',index=False)
S.to_csv(ROOT/'paired_results.csv',index=False)
print(S.to_string(index=False,float_format=lambda x:f'{x:.3f}'))
