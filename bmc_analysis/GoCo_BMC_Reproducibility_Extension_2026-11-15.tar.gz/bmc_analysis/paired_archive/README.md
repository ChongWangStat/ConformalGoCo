# Verified paired comparison of original frozen 100-split results

This directory contains a lossless compact export of split-level **differences in integer counts** calculated from the archived original repository files; see `provenance.json` for the three Git blob SHA values. It is a new post hoc *paired analysis of existing results*, not a new raw-input rerun, ordering ablation, or independent biological validation.

Run `python analyze_transport.py` to regenerate the paired CSVs from `pairs_base64.txt`. Run the independent repository-check script `reproduce_from_repo.py --repo PATH` after the original repository has been cloned (it requires access to its `results/` files, but not the large missing raw inputs).

`paired_split_differences.csv` contains exact integer deltas, and `paired_results.csv` records Monte Carlo summaries. Unlike a confidence interval for biological generalization, these Monte Carlo intervals describe repeated random partitions of each same finite biological panel.
