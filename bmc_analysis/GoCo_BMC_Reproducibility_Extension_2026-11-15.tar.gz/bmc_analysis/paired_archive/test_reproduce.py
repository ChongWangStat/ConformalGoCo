from pathlib import Path
import importlib.util, tempfile, numpy as np, pandas as pd
src=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('paired',src/'reproduce_from_repo.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
d=pd.read_csv(src/'paired_split_differences.csv')
with tempfile.TemporaryDirectory() as t:
 p=Path(t);(p/'results/sf').mkdir(parents=True)
 rows=[]
 for (fam,ds,ctrl),g in d[d.family=='M'].groupby(['family','dataset','control']):
  for z in g.itertuples(index=False):
   # Choose positive constant baseline, then add archived paired differences.
   for arm,sup,total in [('GoDag-cert60',500,2500),('GoCo',500+z.delta_supported,2500+z.delta_total)]:
    rows.append(dict(dataset=ds,seed=z.split,method=arm,alpha=.10,delta=.10,go_yield=sup,total_calls=total))
 pd.DataFrame(rows).to_csv(p/'results/goco_results_100splits.csv',index=False)
 for ds in ['funmap','string']:
  x=d[(d.family=='N')&(d.dataset==ds)]
  g=x[x.control=='GoDagDense'].set_index('split')
  m=x[x.control=='GoCoM'].set_index('split')
  rr=[]
  for k in range(100):
   a=g.loc[k];b=m.loc[k]
   for arm,sup,total in [('goco-N',2000,3000),('global-dense',2000-a.delta_supported,3000-a.delta_total),('goco-M',2000-b.delta_supported,3000-b.delta_total)]:
    rr.append(dict(repeat=k,arm=arm,alpha=.10,delta=.10,correct=sup,total=total))
  pd.DataFrame(rr).to_csv(p/f'results/sf/{ds}_v4_100.csv',index=False)
 got=mod.extract(p).sort_values(['family','dataset','control','split']).reset_index(drop=True)
 true=d.sort_values(['family','dataset','control','split']).reset_index(drop=True)
 pd.testing.assert_frame_equal(got,true,check_dtype=False)
 sums=mod.summarize(got)
 for (fam,ds,ctrl),want in mod.EXPECTED.items():
  x=sums[(sums.family==fam)&(sums.dataset==ds)&(sums.control==ctrl)&(sums.metric=='delta_supported')]
  assert np.isclose(x.mean_difference.iloc[0],want)
 print('PASS: extraction+pairing+statistics reconstitutes all 800 archived paired differences, with expected 8 primary means')
