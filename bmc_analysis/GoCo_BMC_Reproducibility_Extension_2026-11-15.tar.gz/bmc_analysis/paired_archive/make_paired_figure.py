from pathlib import Path
import pandas as pd,numpy as np
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parents[2]
D=pd.read_csv(p/'bmc_analysis/paired_archive/paired_split_differences.csv')
comps=[[('M','Wainberg','GoDag60','Wainberg'),('M','Sanger','GoDag60','Sanger'),('M','DRIVE','GoDag60','DRIVE'),('M','HAP1','GoDag60','HAP1')],[('N','funmap','GoDagDense','FunMap'),('N','string','GoDagDense','STRING')]]
fig,axes=plt.subplots(2,1,figsize=(8.0,5.2),layout='constrained')
for k,(ax,cmps) in enumerate(zip(axes,comps)):
    for j,(fam,d,ctrl,label) in enumerate(cmps):
        v=D[(D.family==fam)&(D.dataset==d)&(D.control==ctrl)].sort_values('split').delta_supported.to_numpy()
        assert len(v)==100
        ax.plot(v,np.full(len(v),j),'.',ms=2,alpha=.25)
        ax.errorbar(v.mean(),j,xerr=1.96*v.std(ddof=1)/np.sqrt(100),fmt='o',capsize=4,markersize=6,linewidth=1.5,color='black')
    ax.axvline(0,color='0.45',lw=.9,ls='--')
    ax.set_yticks(range(len(cmps)),[z[3] for z in cmps]);ax.invert_yaxis()
    ax.set_title('A. GoCo-M versus matched GoDag (60% certification)' if k==0 else 'B. GoCo-N versus refined-grid GoDag (60% certification)',loc='left',fontsize=10)
    ax.set_xlabel('Additional reference-supported gene-GO calls (GoCo minus GoDag)')
    ax.grid(axis='x',alpha=.14)
    ax.set_xlim((-8,55) if k==0 else (-45,715))
fig.suptitle(r'Paired supported-call differences across 100 fixed-panel splits ($\alpha=\delta=0.10$)',fontsize=11)
fig.savefig(p/'FigureS3_paired_changes.pdf',bbox_inches='tight')
fig.savefig(p/'FigureS3_paired_changes.png',dpi=200,bbox_inches='tight')
plt.close(fig)
print('saved revised two-scale paired figure')
