#!/usr/bin/env python3
"""Rebuild the BMC strict-confidence GoCo-N display from the original frozen CSVs.

The files are the archived 100-split outputs, NOT new raw-input reruns.
Usage: python summarize_existing_neighborhood.py --repo /path/to/ConformalGoCo
"""
import argparse
from pathlib import Path
import pandas as pd

def summary(repo):
    rows=[]
    for name in ['funmap','string']:
        f=Path(repo)/'results'/'sf'/f'{name}_v4_100.csv'
        if not f.exists(): raise FileNotFoundError(f'{f}: download the original stored split-level output')
        data=pd.read_csv(f)
        x=data[(data.alpha==0.10)&(data.delta==0.10)&(data.arm.isin(['global-dense','goco-N']))]
        if not all(x.groupby('arm')['repeat'].nunique()==100): raise AssertionError(f'{name}: expected 100 unique splits for each method')
        for arm,df in x.groupby('arm'):
            vals=dict(panel=name,arm=arm,n_splits=len(df),fdp=df.fdp.mean(),calls=df.total.mean(),supported=df.correct.mean(),supported_fraction=df.correct.sum()/df.total.sum())
            rows.append(vals)
    out=pd.DataFrame(rows).sort_values(['panel','arm']).reset_index(drop=True)
    print(out.to_string(index=False,float_format=lambda x: f'{x:.5f}'))
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--repo',required=True);ap.add_argument('--out')
    args=ap.parse_args();out=summary(args.repo)
    if args.out: Path(args.out).parent.mkdir(exist_ok=True,parents=True);out.to_csv(args.out,index=False)
