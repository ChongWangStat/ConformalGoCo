# GoCo-M ordering ablation (BMC Bioinformatics)

**Completed empirical study:** frozen Wainberg, Sanger, DRIVE and HAP1 inputs; 100 original split seeds on each panel; all three fixed within-split hash controls. Exact source code, training labels and matrices are archived in `goco-bmc-module-inputs.zip` (SHA256 in `frozen_input_artifact.sha256`) from the publicly available GitHub repository at commit `0a90988fdb3c918afdf1fa46affe7f6c52009df7`.

All split-level outputs are in `ordering_ablation/`. Verify the publication table with:

```bash
python bmc_analysis/verify_ordering_ablation.py
```

To reproduce from original matrices, unzip `bmc_analysis/goco-bmc-module-inputs.zip` into a new directory, then run for each panel separately (the entire 100-split rerun is computationally intensive):

```bash
mkdir -p frozen_module_repo
cd frozen_module_repo && unzip ../bmc_analysis/goco-bmc-module-inputs.zip && cd ..
python bmc_analysis/run_matched_ablation.py --repo frozen_module_repo --families module --datasets Wainberg --repeats 100 --random-reps 3 --out repeat_Wainberg
python bmc_analysis/run_matched_ablation.py --repo frozen_module_repo --families module --datasets Sanger --repeats 100 --random-reps 3 --out repeat_Sanger
python bmc_analysis/run_matched_ablation.py --repo frozen_module_repo --families module --datasets DRIVE --repeats 100 --random-reps 3 --out repeat_DRIVE
python bmc_analysis/run_matched_ablation.py --repo frozen_module_repo --families module --datasets HAP1 --repeats 100 --random-reps 3 --out repeat_HAP1
```

`run_matched_ablation.py` also has a checkpoint every five splits and supports `--start`/`--repeats` for chunking; concatenate disjoint chunks when reruns exceed a session time limit. This extension does not overwrite archived manuscript results. The ordering contrast is learned biological ordering vs rank-fold-safe, label-free alternatives with the **same candidate grid**. At the original target `alpha=delta=0.10`, Wainberg learned supported-call yield differs by 0.96 in the present rerun versus the archived value of 365.22; the cause is unresolved and may involve dependency version differences (included `frozen_module_repo/code/requirements.txt`). All new ablation contrasts use the *same rerun* and thus are paired consistently. The original manuscript benchmark retains archived values.

**Not performed:** raw-input ordering ablation for FunMap and STRING (their large frozen predictor-score inputs are not present in the public repository) or independent temporal GO confirmation. They are not claims in the updated manuscript.
