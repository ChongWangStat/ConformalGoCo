# BMC revised figure and numerical table outputs (results only)

This archive contains **no manuscript, publisher LaTeX source or supplementary text**. It contains the four principal result tables as CSV, and new supplementary figures S3/S4 as PDFs. All numerical values match the approved BMC results at alpha=delta=0.10.

Table 1 (module-family), Table 2 (neighborhood-family), Table 3 (matched-certification-fold comparisons) and Table 4 (fixed-resolution ordering ablation) are CSV snapshots of the published table data; these can be checked against split-level result outputs in `bmc_analysis/GoCo_BMC_Reproducibility_Extension_2026-11-15.tar.gz` and existing repository `results/`.

`code/plot_bmc_added_figures.py` regenerates both Figure S3 and Figure S4 directly from the archived 100-split pair differences; Figure S3 also has its original `code/make_paired_figure.py` builder. Run `python code/plot_bmc_added_figures.py --data <directory containing bmc_analysis/> --output reproduced_figures` after extracting the extension. The regenerated plots need not be byte-identical to publisher-generated PDFs, but derive the same numerical contrasts. The older main figures were already committed in `paper/figures/` and have Python builders in `code/`.

Generated LaTeX table snippets are not tracked in the revised GitHub release; the published manuscript and LaTeX sources are supplied privately with the journal submission, not on GitHub. Existing builders may generate TeX files locally as intermediate outputs.
