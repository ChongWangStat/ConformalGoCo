# BMC revised figure and numerical table outputs (results only)

This archive contains **no manuscript, publisher LaTeX source or supplementary text**. It contains the four principal result tables as CSV, and new supplementary figures S3/S4 as PDFs. All numerical values match the approved BMC results at alpha=delta=0.10.

Table 1 (module-family), Table 2 (neighborhood-family), Table 3 (matched-certification-fold comparisons) and Table 4 (fixed-resolution ordering ablation) are CSV snapshots of the published table data; these can be checked against split-level result outputs in `bmc_analysis/GoCo_BMC_Reproducibility_Extension_2026-11-15.tar.gz` and existing repository `results/`.

`code/make_paired_figure.py` reproduces Figure S3 from the extension archive's paired split-level differences (run after extracting the extension from repo root). Figure S4 is provided as the published output; its fixed-resolution comparison data and verification code are in the extension archive. The older main figures were already committed in `paper/figures/` and have Python builders in `code/`.

Generated LaTeX table snippets are not tracked in the revised GitHub release; the published manuscript and LaTeX sources are supplied privately with the journal submission, not on GitHub. Existing builders may generate TeX files locally as intermediate outputs.
