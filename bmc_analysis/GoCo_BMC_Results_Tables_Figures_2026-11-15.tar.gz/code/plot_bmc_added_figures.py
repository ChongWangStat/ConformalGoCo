"""Replot BMC supplementary figures S3 and S4 from stored 100-split results.

Run from the repository root after unpacking the two BMC data bundles:
python code/plot_bmc_added_figures.py --data bmc_unpacked --output bmc_replotted

Figure S3 uses bmc_analysis/paired_archive/paired_split_differences.csv.
Figure S4 uses bmc_analysis/ordering_ablation/paired_per_split.csv.
The figures are reproduced from frozen split differences; styling need not be
byte-identical to the publisher's PDF rendering.
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def plot_s3(input_root: Path, output: Path):
    d = pd.read_csv(input_root / 'bmc_analysis/paired_archive/paired_split_differences.csv')
    comps = [[('M','Wainberg','GoDag60','Wainberg'),('M','Sanger','GoDag60','Sanger'),('M','DRIVE','GoDag60','DRIVE'),('M','HAP1','GoDag60','HAP1')], [('N','funmap','GoDagDense','FunMap'),('N','string','GoDagDense','STRING')]]
    fig,axes=plt.subplots(2,1,figsize=(8.1,5.2),layout='constrained')
    for k,(ax,rows) in enumerate(zip(axes,comps)):
        for j,(family,panel,cmp,label) in enumerate(rows):
            x=d[(d.family==family)&(d.dataset==panel)&(d.control==cmp)].sort_values('split').delta_supported.to_numpy()
            if len(x)!=100: raise ValueError((label,len(x)))
            ax.plot(x,np.full(len(x),j),'.',ms=2,alpha=.25)
            ax.errorbar(x.mean(),j,xerr=1.96*x.std(ddof=1)/np.sqrt(100),fmt='o',capsize=4,markersize=6,linewidth=1.5,color='black')
        ax.axvline(0,color='0.45',lw=.9,ls='--'); ax.set_yticks(range(len(rows)),[z[3] for z in rows]);ax.invert_yaxis()
        ax.set_title('A. GoCo-M versus matched GoDag' if k==0 else 'B. GoCo-N versus refined-grid GoDag',loc='left',fontsize=10)
        ax.set_xlabel('Difference in reference-supported released gene-GO calls')
        ax.grid(axis='x',alpha=.15)
    fig.savefig(output/'FigureS3_paired_changes_regenerated.pdf',bbox_inches='tight');plt.close(fig)


def plot_s4(input_root: Path,output: Path):
    d=pd.read_csv(input_root/'bmc_analysis/ordering_ablation/paired_per_split.csv')
    panels=['Wainberg','Sanger','DRIVE','HAP1']
    fig,ax=plt.subplots(figsize=(8,4),layout='constrained')
    for i,panel in enumerate(panels):
        for shift,comp,lab,mark in [(-.15,'random','Learned – hash','o'),(.15,'score-only','Learned – score-only','s')]:
            x=d[(d.dataset==panel)&(d.comparison==comp)&(d.metric=='go_yield')].sort_values('seed').difference.to_numpy()
            if len(x)!=100:raise ValueError((panel,comp,len(x)))
            y=i+shift
            ax.errorbar(x.mean(),y,xerr=1.96*x.std(ddof=1)/np.sqrt(len(x)),fmt=mark,markersize=5,capsize=3,color=('black' if comp=='random' else '0.5'),label=lab if i==0 else None)
    ax.axvline(0,color='0.45',linestyle='--',linewidth=1)
    ax.set_yticks(range(len(panels)),panels);ax.invert_yaxis();ax.grid(axis='x',alpha=.14)
    ax.set_xlabel('Additional reference-supported gene–GO calls (learned minus control)')
    ax.set_title('GoCo-M fixed-resolution ordering ablation, 100 matched splits',loc='left')
    ax.legend(loc='lower right')
    fig.savefig(output/'FigureS4_ordering_ablation_regenerated.pdf',bbox_inches='tight');plt.close(fig)
    return d


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,default=Path('.'));p.add_argument('--output',type=Path,default=Path('bmc_replotted'))
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    plot_s3(a.data,a.output); d=plot_s4(a.data,a.output)
    for dataset in ['Wainberg','Sanger','DRIVE','HAP1']:
        means=[d[(d.dataset==dataset)&(d.comparison==k)&(d.metric=='go_yield')].difference.mean() for k in ('random','score-only')]
        print(dataset,'learned-minus-hash and learned-minus-score',*[round(x,3) for x in means])
