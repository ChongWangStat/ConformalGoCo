param([string]$PdfLaTeX = 'pdflatex')
$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath $PSScriptRoot
try {
    $taskBuild = Join-Path $PSScriptRoot 'build'
    if (-not (Test-Path -LiteralPath $taskBuild)) {
        New-Item -ItemType Directory -Path $taskBuild | Out-Null
    }
    $taskBuild = (Resolve-Path -LiteralPath $taskBuild).Path.Replace('\','/')
    foreach ($taskStem in @('GoCo_main','GoCo_supplement','GoCo_main','GoCo_supplement','GoCo_main')) {
        & $PdfLaTeX '-interaction=nonstopmode' '-halt-on-error' ('-output-directory='+$taskBuild) ($taskStem+'.tex')
        if ($LASTEXITCODE -ne 0) { throw ('Compilation failed: '+$taskStem) }
    }
    Write-Output ('Completed PDFs: '+$taskBuild)
}
finally { Pop-Location }
