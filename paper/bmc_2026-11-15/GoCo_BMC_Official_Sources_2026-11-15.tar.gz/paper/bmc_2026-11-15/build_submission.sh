#!/bin/sh
set -eu
# Springer Nature official sn-jnl v3.1 (2024), BMC Bioinformatics submission.
# Run from this directory with pdfLaTeX installed.
pdflatex -interaction=nonstopmode -halt-on-error BMC_GoCo_supplement.tex
pdflatex -interaction=nonstopmode -halt-on-error BMC_GoCo_main.tex
pdflatex -interaction=nonstopmode -halt-on-error BMC_GoCo_supplement.tex
pdflatex -interaction=nonstopmode -halt-on-error BMC_GoCo_main.tex
cp BMC_GoCo_supplement.pdf Additional_file_1_GoCo_Supplement.pdf
if command -v python >/dev/null 2>&1 && python -c 'import fitz' >/dev/null 2>&1; then
  python combine_bmc.py
else
  printf 'Main and Additional File 1 PDFs built. Optional combination requires PyMuPDF.\n'
fi
