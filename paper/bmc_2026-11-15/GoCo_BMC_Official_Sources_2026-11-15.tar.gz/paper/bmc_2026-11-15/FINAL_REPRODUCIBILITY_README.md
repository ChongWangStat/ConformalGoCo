# BMC Bioinformatics final source and reproducibility

- Approved final LaTeX: `BMC_GoCo_main.tex` (official Springer Nature template) and `BMC_GoCo_supplement.tex` (Additional file 1).
- Build from this folder: `sh build_submission.sh`; the included figures and class are sufficient. The combined manuscript and supplement comprise 64 pages.
- Two precise changes from the previously approved focused version: remove two unnecessary Discussion sentences about the former delta=0.50 benchmark and shared data reference; remove the unverified Zenodo citation and cite the GitHub repository only.
- Reproduction code, the source frozen-module inputs, the 100-split results and provenance are bundled in the separate `GoCo_BMC_Final_Reproducibility_2026-11-15.zip` artifact.
- Run `python bmc_analysis/verify_ordering_ablation.py` and `python bmc_analysis/paired_archive/test_reproduce.py` after extracting the reproducibility archive. Both verification scripts passed on the archived data in this build.
- The public GitHub repository is https://github.com/ChongWangStat/ConformalGoCo; its 2026-09 main branch has some earlier table labels and figures. The full final local reproducibility archive is the authoritative updated file set until its new Github commit is verified.
- The original author-submitted archive is present as `BASELINE_Original_Submission.zip` for exact historical comparison.
