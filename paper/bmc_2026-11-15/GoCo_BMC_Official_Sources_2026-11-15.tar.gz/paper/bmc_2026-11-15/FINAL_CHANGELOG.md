# GoCo final submission changes, 2026-11-15

Author-approved final narrow changes since the previously audited BMC manuscript:

1. Remove two Discussion sentences: (i) historical delta=0.50 vs principal delta=0.10, already described in Results and supplement; (ii) shared gene universe/reference for Sanger, DRIVE and HAP1, already addressed in data description. Keep the actual theorem scope and assumption.
2. Remove Zenodo data-availability claim and Zenodo reference pending verification of its automatic GitHub-release integration, per author instruction; cite GitHub as sole code access URL.
3. No other scientific wording, numerical results, figures, proofs, AI declarations or author details changed.
4. The updated GitHub revision remains a separate required synchronization step; do not claim it has been completed until publicly verified.
