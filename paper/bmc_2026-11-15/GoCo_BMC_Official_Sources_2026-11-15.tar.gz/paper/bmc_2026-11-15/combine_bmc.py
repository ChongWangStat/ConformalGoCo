from pathlib import Path
from pypdf import PdfReader, PdfWriter
from pypdf.generic import (ArrayObject, DictionaryObject, NameObject, FloatObject, NullObject)
root=Path(__file__).resolve().parent
out=root/'GoCo_BMC_Main_and_Supplement.pdf'
main=root/'BMC_GoCo_main.pdf';supp=root/'BMC_GoCo_supplement.pdf'
source_readers={'BMC_GoCo_main.pdf':PdfReader(str(main)), 'BMC_GoCo_supplement.pdf':PdfReader(str(supp))}
a,b=source_readers.values()
w=PdfWriter();w.append(str(main));w.append(str(supp))
w.add_outline_item('Main manuscript',0)
w.add_outline_item('Supplementary material',len(a.pages))
w.add_metadata({'/Title':'GoCo: structure-guided conformal calibration for Gene Ontology annotation release with gene-level risk control','/Author':'Chong Wang, Yongzhao Shao, Peng Liu','/Subject':'BMC Bioinformatics research article revision with supplement'})
converted=0;problems=[]
for pageidx,page in enumerate(w.pages):
    for ref in page.get('/Annots',[]):
        annot=ref.get_object(); action=annot.get('/A')
        if not action or action.get('/S')!='/GoToR': continue
        target_file=str(action.get('/F',''))
        name=str(action.get('/D',''))
        sr=source_readers.get(target_file)
        if sr is None or name not in sr.named_destinations:
            problems.append((pageidx,target_file,name,'named destination not present'));continue
        dest=sr.named_destinations[name]
        relative=sr.get_destination_page_number(dest)
        if relative<0:
            problems.append((pageidx,target_file,name,'page not found'));continue
        target_global=relative+(len(a.pages) if target_file=='BMC_GoCo_supplement.pdf' else 0)
        target_page_ref=w.pages[target_global].indirect_reference
        x=dest.get('/Left')
        y=dest.get('/Top')
        new_dest=ArrayObject([target_page_ref,NameObject('/XYZ'),FloatObject(float(x or 0)),FloatObject(float(y or 0)),NullObject()])
        annot[NameObject('/A')]=DictionaryObject({NameObject('/S'):NameObject('/GoTo'), NameObject('/D'):new_dest})
        converted+=1
if problems:raise RuntimeError(f'Unconverted cross-document links: {problems[:10]} ({len(problems)} in total)')
with out.open('wb') as f:w.write(f)
c=PdfReader(out)
assert len(c.pages)==len(a.pages)+len(b.pages)
links={}
for j,page in enumerate(c.pages):
    for ref in page.get('/Annots',[]):
        ob=ref.get_object()
        if str(ob.get('/Subtype',''))!='/Link': continue
        action=ob.get('/A'); val=str(action.get('/S')) if action else 'Dest'
        links[val]=links.get(val,0)+1
assert not links.get('/GoToR'),links
print('combined=',out,'main_pages=',len(a.pages),'supp_pages=',len(b.pages),'total=',len(c.pages))
print('cross_document_links_converted=',converted,'hyperlinks=',links,'bytes=',out.stat().st_size)
